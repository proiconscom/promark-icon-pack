ProMark Icon Pack
=================
Version: 1.0.0
Total icons: 35 (13 static + 22 animated)
Format: SVG
License: MIT
Website: https://proicons.com/icon-collections/promark-icon-pack/


ABOUT
-----
ProMark is the official branded icon mark of proIcons, offered here as a
standalone icon pack. Every icon in this pack uses the same 120x120 px canvas,
rx=28 rounded background, and four geometric shapes: circle, X cross, triangle,
and square - arranged on a strict 45px grid.

The pack ships in two flavours:

  static/    - Plain SVG icons, no scripting, zero dependencies.
               Drop into any HTML, CSS, or design tool.

  animated/  - Hover-triggered animated SVG icons. Each icon contains
               self-contained CSS keyframes and a small inline script.
               No external libraries required.
               Hover to play. Move away to watch shapes glide back home.


STATIC ICONS (13)
-----------------
promark-static-green.svg       Green gradient (original brand colour)
promark-static-blue.svg        Blue gradient
promark-static-purple.svg      Purple gradient
promark-static-fire.svg        Orange-red fire gradient
promark-static-teal.svg        Teal-cyan gradient
promark-static-pink.svg        Pink-fuchsia gradient
promark-static-gold.svg        Gold-amber gradient
promark-static-sky.svg         Sky-indigo gradient
promark-static-neon.svg        Dark background, multicolour neon strokes
promark-static-glass.svg       Sky-indigo gradient with frosted glass effect
promark-static-dark.svg        Dark background, white strokes
promark-static-mono-light.svg  White background, black strokes
promark-static-mono-dark.svg   Black background, white strokes


ANIMATED ICONS (22)
-------------------
Color variations - orbit animation on 8 gradients:
  promark-green.svg
  promark-blue.svg
  promark-purple.svg
  promark-fire.svg
  promark-teal.svg
  promark-pink.svg
  promark-gold.svg
  promark-sky.svg

Motion styles - 6 choreographies on the green mark:
  promark-counter.svg        Anti-clockwise orbit
  promark-scatter.svg        Shapes fly to outer corners
  promark-pulse.svg          Each shape scales from its own centre
  promark-wave.svg           Staggered Y-axis oscillation
  promark-spin.svg           Each shape rotates on its own axis
  promark-bounce.svg         Springy vertical jump

Combos - colour + motion pairings:
  promark-blue-counter.svg   Blue + anti-clockwise orbit
  promark-purple-orbit.svg   Purple + clockwise orbit
  promark-fire-scatter.svg   Fire + scatter
  promark-teal-orbit.svg     Teal + clockwise orbit
  promark-pink-wave.svg      Pink + wave
  promark-gold-spin.svg      Gold + spin
  promark-neon-orbit.svg     Neon multicolour + orbit (dark bg)
  promark-glass-bounce.svg   Glass frosted + bounce


ANIMATION SPECS
---------------
Canvas:        120 x 120 px
Corner radius: rx=28
Stroke width:  6 px (5 px on glass variant)
Grid step:     45 px
Trigger:       CSS hover (:hover via JS mouseenter/mouseleave)
Play duration: 1.2s - 2.0s depending on style
Return:        0.6s cubic-bezier(0.4, 0, 0.2, 1) ease-out
Dependencies:  None - pure CSS keyframes + inline vanilla JS


USAGE
-----
Static icons - use like any SVG:
  <img src="promark-static-green.svg" width="48" height="48" alt="proIcons">

Animated icons - embed inline for hover to work:
  Paste the SVG source directly into your HTML. The inline script handles
  mouseenter (play) and mouseleave (smooth return to home position).
  Alternatively, use in an <img> tag for a static fallback -
  animation requires inline embedding or an <object> tag.

React / Vue - embed as a component using your framework's SVG import method.


LICENSE
-------
MIT License

Copyright (c) 2026 proIcons (proicons.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.


LINKS
-----
Website:   https://proicons.com
Pack page: https://proicons.com/icon-collections/promark-icon-pack/
Contact:   https://proicons.com/contact/
